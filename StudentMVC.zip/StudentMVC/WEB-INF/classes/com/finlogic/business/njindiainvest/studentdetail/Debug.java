package com.finlogic.business.njindiainvest.studentdetail;

public class Debug
{

    private static java.util.Date currentDate = new java.util.Date();
    public static final String strErrorLogFilePath = finpack.FinPack.getProperty("tomcat1_path")+"/webapps/StudentMVC/log/" + currentDate.getDate() + "-" + (currentDate.getMonth() + 1) + "-" + (currentDate.getYear() + 1900) + "_log1.txt";
    public static final String strErrorLogFilePathForWebService = finpack.FinPack.getProperty("tomcat1_path")+"/webapps/customercare/log/" + currentDate.getDate() + "-" + (currentDate.getMonth() + 1) + "-" + (currentDate.getYear() + 1900) + "_logWebService.txt";
    public static final String strErrorLogFilePath1 = finpack.FinPack.getProperty("tomcat1_path")+"/webapps/customercare/log/log2.txt";

    //Function for writing to file
    public static void appendLogFile(String data)
    {
        finutils.errorhandler.ErrorHandler.PrintInLog(strErrorLogFilePath, data);
    }

    public static void appendLogFile1(String data)
    {
        finutils.errorhandler.ErrorHandler.PrintInLog(strErrorLogFilePath1, data);
    }

    public static void appendLogFileForWebService(String data)
    {
        finutils.errorhandler.ErrorHandler.PrintInLog(strErrorLogFilePathForWebService, data);
    }

    public static String printStackTrace(Exception ex)
    {
        StringBuilder sbStackTrace = new StringBuilder();
        sbStackTrace.append(ex.toString());
        for (int i = 0; i < ex.getStackTrace().length; i++)
        {
            sbStackTrace.append(i).append(" ClassName  : ").append(ex.getStackTrace()[i].getClassName()).append("\n");
            sbStackTrace.append(i).append(" MethodName  : ").append(ex.getStackTrace()[i].getMethodName()).append("\n");
            sbStackTrace.append(i).append(" LineNumber  : ").append(ex.getStackTrace()[i].getLineNumber()).append("\n");
        }
        return sbStackTrace.toString();
    }
}