/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.apps.njindiainvest.studentdetail;

import com.finlogic.business.njindiainvest.studentdetail.Debug;

import com.finlogic.util.persistence.SQLUtility;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author njuser
 */
public class studentDetaildataManager {
    
    private static final String ALIASNAME = "njindiainvest_offline";
    private final SQLUtility sqlUtility = new SQLUtility();
    
    public List getDegree() throws ClassNotFoundException, SQLException
    {
        StringBuilder query = new StringBuilder();
        query.append("Select * from njindiainvest.Degree_Master");
        return sqlUtility.getList(ALIASNAME, query.toString());
    }
    
    public List getYear(String degree) throws ClassNotFoundException, SQLException
    {
        StringBuilder stb = new StringBuilder();
        stb.append("select degree_id from njindiainvest.Degree_Master where ");
        stb.append(" degree_name = '").append(degree).append("'");
        
        
        Debug.appendLogFile("get degree id  === "+ stb.toString());
        String deg = sqlUtility.getString(ALIASNAME, stb.toString());
        
        StringBuilder query = new StringBuilder();
        query.append("select * from njindiainvest.Year_Master where ");
        query.append("degree_id = '").append(deg).append("'");
        
        Debug.appendLogFile("Year query  === "+ query.toString());
        return sqlUtility.getList(ALIASNAME, query.toString());
        
    }
    
    public List getGridData(studentDetailformBean formBean) throws ClassNotFoundException, SQLException
    {
        StringBuilder query = new StringBuilder();
        List lst = new ArrayList();
        query.append("select enroll_no, CONCAT('<img  height=100 width=100 src=/StudentMVC/photo/' ,photo, '>'),  name, address, city, email, dob, gender, degree, year, hobby, CONCAT('<a name=enroll_no onclick=javascript:EditData(',enroll_no,') name=enroll_no href=javascript:void(0)> <img src=http://test.njindiainvest.com/finlibrary/resource/images/edit.gif height=20px; width=20px; > </a>'), CONCAT('<a name=enroll_no onclick=javascript:DeleteData(',enroll_no,') name=enroll_no href=javascript:void(0)> <img src=http://test.njindiainvest.com/finlibrary/resource/images/delete.gif height=20px; width=20px; > </a>')from njindiainvest.student WHERE 1=1");
        
        if (formBean.getTxtsedit()!= null && !formBean.getTxtsedit().trim().equals("")) {
            query.append(" AND  name like '");
            query.append(formBean.getTxtsedit());
            query.append("%'");
            query.append(" OR  address like '%");
            query.append(formBean.getTxtsedit());
            query.append("%'");
        }
        
        if (formBean.getTxtsdelete()!= null && !formBean.getTxtsdelete().trim().equals("")) {
            query.append(" AND  name like '");
            query.append(formBean.getTxtsdelete());
            query.append("%'");
            query.append(" OR  address like '%");
            query.append(formBean.getTxtsdelete());
            query.append("%'");
        }
        
        if (formBean.getTxtsview()!= null && !formBean.getTxtsview().trim().equals("")) {
            query.append(" AND  name like '");
            query.append(formBean.getTxtsview());
            query.append("%'");
            query.append(" OR  address like '%");
            query.append(formBean.getTxtsview());
            query.append("%'");
            Debug.appendLogFile("Txts View === " +formBean.getTxtsview());
        }
        
        
        Debug.appendLogFile("Student === "+ query.toString());
        
        return sqlUtility.getList(ALIASNAME, query.toString());
    }
    
    public List DeleteLoaderMain(studentDetailformBean formBean) throws ClassNotFoundException, SQLException
    {
        StringBuilder query = new StringBuilder();
        query.append("select * from njindiainvest.student");
        query.append(" where enroll_no = '").append(formBean.getPrimekey()).append("'");
        Debug.appendLogFile(query.toString());
        return sqlUtility.getList(ALIASNAME, query.toString());
    }
    
    public List EditMainLoader(studentDetailformBean formBean) throws ClassNotFoundException, SQLException
    {
        StringBuilder query = new StringBuilder();
        query.append("select * from njindiainvest.student");
        query.append(" where enroll_no = '").append(formBean.getPrimekey()).append("'");
        
        Debug.appendLogFile(query.toString());
        return sqlUtility.getList(ALIASNAME, query.toString());
    }
    
    public int delete_student(studentDetailformBean formBean) throws ClassNotFoundException, SQLException
    {
        StringBuilder query = new StringBuilder();
        query.append("delete from njindiainvest.student where enroll_no = '").append(formBean.getPrimekey()).append("'");
        Debug.appendLogFile(query.toString());
        return sqlUtility.persist(ALIASNAME, query.toString());
        //return sqlUtility.getInt(ALIASNAME, query.toString());
    }
    
    public int update_student(studentDetailformBean formBean, String fileName) throws ClassNotFoundException, SQLException
    {
        StringBuilder stb = new StringBuilder();
        stb.append("UPDATE njindiainvest.student SET ");
        stb.append("name='").append(formBean.getTxtsname()).append("', address='").append(formBean.getTxtsadd()).append("', city='").append(formBean.getTxtscity()).append("', email='").append(formBean.getTxtsemail()).append("', dob='").append(formBean.getDtdob()).append("', gender='").append(formBean.getRadiogender()).append("', degree='").append(formBean.getDropdegree()).append("', year='").append(formBean.getDropyear()).append("', hobby='").append(formBean.getSelhobby()).append("', photo='").append(fileName);
        stb.append("' WHERE enroll_no ='").append(formBean.getPrimekey()).append("'");
        
        Debug.appendLogFile("Update Query = "+ stb.toString());
        return sqlUtility.persist(ALIASNAME, stb.toString());
    }
    
    public int insert_student(studentDetailformBean formBean, String fileName) throws ClassNotFoundException, SQLException
    {
        int temp;
        temp = getEnroll();
        temp+=1;
        
        //String fileName ="null";
        
        StringBuilder query = new StringBuilder();
        query.append("insert into njindiainvest.student (enroll_no, name, address, city, email, dob, gender, degree, year, hobby, photo)");
        query.append(" values ");
        query.append("('").append(temp).append("', '").append(formBean.getTxtsname()).append("', '").append(formBean.getTxtsadd()).append("', '").append(formBean.getTxtscity()).append("', '").append(formBean.getTxtsemail()).append("', '").append(formBean.getDtdob()).append("', '").append(formBean.getRadiogender()).append("', '").append(formBean.getDropdegree()).append("', '").append(formBean.getDropyear()).append("', '").append(formBean.getSelhobby()).append("', '").append(fileName).append("')");
        
        Debug.appendLogFile("Insert Query = "+ query.toString());
        
        return sqlUtility.persist(ALIASNAME, query.toString());
    }
    
    public int getEnroll() throws ClassNotFoundException, SQLException
    {
        StringBuilder query = new StringBuilder();
        query.append("select enroll_no from njindiainvest.student ORDER BY enroll_no DESC limit 1");
        Debug.appendLogFile("Enrollment Query = "+ query.toString());
        List count=sqlUtility.getList(ALIASNAME, query.toString());
        
        if(count.isEmpty()){
            return 1;
        }
        else{
            Map mp=new HashMap();
             mp = (Map) count.get(0);
            return Integer.parseInt(mp.get("enroll_no").toString());
        }
//        return sqlUtility.getInt(ALIASNAME, query.toString());
    }
}
