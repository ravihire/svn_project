/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.finlogic.apps.njindiainvest.studentdetail;

import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author njuser
 */
public class studentDetailformBean {
    
    private String enroll_no;
    private String txtsname;
    private String txtsadd;
    private String txtscity;
    private String txtsemail;
    private String dtdob;
    private String radiogender;
    private String dropdegree; 
    private String dropyear;
    private String selhobby;
    private String txtsdelete;
    private String txtsedit;
    private String txtsview;
    private String primekey;
    private String reportName;
    private String displayMode;
    private String radioreport;
    
    private MultipartFile file;

    public String getEnroll_no() {
        return enroll_no;
    }

    public void setEnroll_no(String enroll_no) {
        this.enroll_no = enroll_no;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    public String getDisplayMode() {
        return displayMode;
    }

    public void setDisplayMode(String displayMode) {
        this.displayMode = displayMode;
    }

    public String getRadioreport() {
        return radioreport;
    }

    public void setRadioreport(String radioreport) {
        this.radioreport = radioreport;
    }

    
    
    public MultipartFile getFile()
    {
        return file;
    }
    
    public void setFile(MultipartFile file)
    {
        this.file = file;
    }
    
    public String getTxtsname() {
        return txtsname;
    }

    public void setTxtsname(String txtsname) {
        this.txtsname = txtsname;
    }

    public String getTxtsadd() {
        return txtsadd;
    }

    public void setTxtsadd(String txtsadd) {
        this.txtsadd = txtsadd;
    }

    public String getTxtscity() {
        return txtscity;
    }

    public void setTxtscity(String txtscity) {
        this.txtscity = txtscity;
    }

    public String getTxtsemail() {
        return txtsemail;
    }

    public void setTxtsemail(String txtsemail) {
        this.txtsemail = txtsemail;
    }

    public String getDtdob() {
        return dtdob;
    }

    public void setDtdob(String dtdob) {
        this.dtdob = dtdob;
    }

    public String getRadiogender() {
        return radiogender;
    }

    public void setRadiogender(String radiogender) {
        this.radiogender = radiogender;
    }

    public String getDropdegree() {
        return dropdegree;
    }

    public void setDropdegree(String dropdegree) {
        this.dropdegree = dropdegree;
    }

    public String getDropyear() {
        return dropyear;
    }

    public void setDropyear(String dropyear) {
        this.dropyear = dropyear;
    }

    public String getSelhobby() {
        return selhobby;
    }

    public void setSelhobby(String selhobby) {
        this.selhobby = selhobby;
    }

    public String getTxtsdelete() {
        return txtsdelete;
    }

    public void setTxtsdelete(String txtsdelete) {
        this.txtsdelete = txtsdelete;
    }

    public String getTxtsedit() {
        return txtsedit;
    }

    public void setTxtsedit(String txtsedit) {
        this.txtsedit = txtsedit;
    }

    public String getTxtsview() {
        return txtsview;
    }

    public void setTxtsview(String txtsview) {
        this.txtsview = txtsview;
    }

    public String getPrimekey() {
        return primekey;
    }

    public void setPrimekey(String primekey) {
        this.primekey = primekey;
    }
   
    
}
