/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function AddLoader()
{
    
    var param = getFormData(document.studentForm);
    getSynchronousData('student.fin?cmdAction=AddLoader', param, 'load');
    loadDatePicker("dtdob");
    doOnLoad();
    onLoadCombo();
    document.getElementById("basicReportDiv").style.display = "none";
    document.getElementById("txtsname").focus();
    if (document.getElementById("load").style.display === "none")
    {
        hide_menu('show_hide', 'load', 'nav_show', 'nav_hide');
    }
}

function getDegree()
{
    getSynchronousData('student.fin?cmdAction=getDegree', '', 'load');
}

function EditLoader()
{
    document.getElementById("basicReportDiv").style.display = "none";
    var param = getFormData(document.studentForm);
    getSynchronousData('student.fin?cmdAction=EditLoader', param, 'load');
    document.getElementById("txtsedit").focus();
    if(document.getElementById("load").style.display === "none")
    {
        hide_menu('show_hide','load','nav_show','nav_hide');
    }
}

function degreeLoader()
{
    var param = "&dropdegree="+ document.getElementById("dropdegree").value;
    getDataFilterNew("student.fin?cmdAction=degreeLoader","dropyear", param, false);
    
}

function onLoadCombo()
{
    loadComboNew("dropdegree", "", "", "studentForm");
    loadComboNew("dropyear", "", "", "studentForm");
}

function validate_data()
{
    if(document.getElementById("btnsAdd").value === "Add")
    {
        if(validate_form())
        {
            insert_data();
        }
    }
    else if(document.getElementById("btnsAdd").value === "Update")
    {
        if (validate_form()) 
        {
            if (confirm("Are you sure you want to edit this record ?"))
            {
                insert_data();
            }
            else
            {

            }
        }
    }
    else if(document.getElementById("btnsAdd").value == "Delete")
    {   
        if (confirm("Are you sure you want to delete this record ?"))
        {
            insert_data();
        }
        else
        {

        }
       
    }
}


function insert_data()
{
    if (document.getElementById("btnsAdd").value == "Add")
    {
        if (!displayMsg)
        {
            alert("Please upload valid file. The file must be photo with following extensions(jpg,jpeg,png,gif).");
            return false;
        }
        
        var myUploader = myForm.getUploader("myFiles");
        myUploader.upload();
        
        var param = getFormData(document.studentForm);
        
        getSynchronousData('student.fin?cmdAction=insert_student', param, 'load');
        
        if (document.getElementById("AddCount"))
        {
            
            if (document.getElementById("AddCount").value > 0)
            {
                alert("Record has been inserted successfully..");
                //window.location.reload();
            }
            else
            {
                alert("Problem in record insertion");
            }
        }
        
    }
    else if (document.getElementById("btnsAdd").value == "Update")
    {
        var myUploader = myForm.getUploader("myFiles");
        myUploader.upload();
        
        var param = getFormData(document.studentForm);

        getSynchronousData('student.fin?cmdAction=update_student', param, 'load');
        
        
        if (document.getElementById("AddCount"))
        {
            if (document.getElementById("AddCount").value > 0)
            {
                alert("Record has been updated successfully..");
                //window.location.reload();
            }
            else
            {
                alert("Problem in record updation");
            }
        }
    }
    else if (document.getElementById("btnsAdd").value == "Delete")
    {
        param = getFormData(document.studentForm);
        
        getSynchronousData('student.fin?cmdAction=delete_student', param, 'load');
        
        if (document.getElementById("AddCount"))
        {
            if (document.getElementById("AddCount").value > 0)
            {
                alert("Record has been deleted successfully");
                //window.location.reload();
            }
            else
            {
                alert("Problem in record deletion");
            }
        }
    }
}

var displayMsg = false;
var myForm;

function doOnLoad()
{
 
    var formData;
    var param = getFormData(document.studentForm);
    var swfPathStr="http://dev.njindiaonline.com/finlibrary/dhtmlxSuite/dhtmlxForm/codebase/ext/uploader.swf";
    //dhtmlx.skin = "dhx_web";
    
    formData = [{
        type: "fieldset",
        label: "Upload Photo",
        list:[{
            type: "upload",
            name: "myFiles",
            inputWidth: 200,
            
            url: "student.fin?cmdAction=photoUpload",
            swfPath: swfPathStr,
//            swfUrl: "student.fin?cmdAction=fileUpload"
        }]
    }];
    
    
    myForm = new dhtmlXForm("dhtmlxmyForm", formData);
    
    var count =0;
    
    var upld = document.getElementsByClassName("button_upload");
    for (var i = 0; i < upld.length; i++)
    {
        upld[i].style.display = "none";
    }
    
    var browse = document.getElementsByClassName("button_browse");
    for (var i = 0; i < browse.length; i++)
    {
        browse[i].style.right = "25px";
    }
    
    myForm.attachEvent("onClear", function () {
        
        var upld = document.getElementsByClassName("button_upload");
        for (var i = 0; i < upld.length; i++)
        {
            upld[i].style.display = "none";
        }
         count = count - 1;
    });
    
    myForm.attachEvent("onBeforeFileAdd",function(realName, size){
        
        count++;
        displayMsg = true;
        
        var upld = document.getElementsByClassName("button_upload");
        for (var i = 0; i < upld.length; i++)
        {
            upld[i].style.display = "none";
        }
        
        
        
        if (count > 1)
        {
            alert("You can enter only 1 file");
            if (count !== 0)
            {
                count = count - 1;
            }
            return false;
        }
        
        if (size > 1048576)
        {
            if (count !== 0)
            {
                count = count - 1;
            }
            alert("Photo size should not be greater then 1 MB");
            return false;
        }
        
        var reExp=/(.jpg|.gif|.png|.jpeg)$/i;
        if(!reExp.test(realName))
        {
            alert("Please upload valid file '"+realName+"'. The file must be photo with following extensions(jpg,jpeg,png,gif).");
            return false;
        }
        else
        {
            return true;
        }
    });
    
    myForm.attachEvent("onFileRemove", function (realName, serverName) {
        var upld = document.getElementsByClassName("button_upload");
        for (var i = 0; i < upld.length; i++)
        {
            upld[i].style.display = "none";
        }
        if (count !== 0)
        {
            count = count - 1;
        }
        displayMsg = false;
    });
    
    myForm.attachEvent("onUploadComplete", function(count) {
        
        alert("File"+(count > 1 ? "(s)": "")+" Successfully Uploaded.");
        
    });
    
    myForm.attachEvent("onUploadFail", function(realName) {
        
        var upld = document.getElementsByClassName("button_upload");
        for (var i = 0; i < upld.length; i++)
        {
            upld[i].style.display = "none";
        }
        
        if(displayMsg == false)
        {
            alert("File upload fail due to some problem.");
        }
    });
    
    myForm.attachEvent("onUploadFile", function (realName, serverName)
    {
        
    });
    
}


function doOnLoadEdit()
{
 
    var formData;
    var param = getFormData(document.studentForm);
    var swfPathStr="http://dev.njindiaonline.com/finlibrary/dhtmlxSuite/dhtmlxForm/codebase/ext/uploader.swf";
    //dhtmlx.skin = "dhx_web";
    
    formData = [{
        type: "fieldset",
        label: "Upload Photo",
        list:[{
            type: "upload",
            name: "myFiles",
            inputWidth: 200,
            
            url: "student.fin?cmdAction=photoUpload&primekey="+document.getElementById("primekey").value,
            swfPath: swfPathStr,
//            swfUrl: "student.fin?cmdAction=fileUpload"
        }]
    }];
    
    
    myForm = new dhtmlXForm("dhtmlxmyForm", formData);
    
    var count =0;
    
    var upld = document.getElementsByClassName("button_upload");
    for (var i = 0; i < upld.length; i++)
    {
        upld[i].style.display = "none";
    }
    
    var browse = document.getElementsByClassName("button_browse");
    for (var i = 0; i < browse.length; i++)
    {
        browse[i].style.right = "25px";
    }
    
    myForm.attachEvent("onClear", function () {
        
        var upld = document.getElementsByClassName("button_upload");
        for (var i = 0; i < upld.length; i++)
        {
            upld[i].style.display = "none";
        }
    });
    
    myForm.attachEvent("onBeforeFileAdd",function(realName, size){
        count++;
        displayMsg = true;
        
        var upld = document.getElementsByClassName("button_upload");
        for (var i = 0; i < upld.length; i++)
        {
            upld[i].style.display = "none";
        }
        
        
        
        if (count > 1)
        {
            alert("You can enter only 1 file");
            if (count !== 0)
            {
                count = count - 1;
            }
            return false;
        }
        
        if (size > 1048576)
        {
            if (count !== 0)
            {
                count = count - 1;
            }
            alert("Photo size should not be greater then 1 MB");
            return false;
        }
        
        var reExp=/(.jpg|.gif|.png|.jpeg)$/i;
        if(!reExp.test(realName))
        {
            alert("Please upload valid file '"+realName+"'. The file must be photo with following extensions(jpg,jpeg,png,gif).");
            return false;
        }
        else
        {
            return true;
        }
    });
    
    myForm.attachEvent("onFileRemove", function (realName, serverName) {
        var upld = document.getElementsByClassName("button_upload");
        for (var i = 0; i < upld.length; i++)
        {
            upld[i].style.display = "none";
        }
        if (count !== 0)
        {
            count = count - 1;
        }
        displayMsg = false;
    });
    
    myForm.attachEvent("onUploadComplete", function(count) {
        
        alert("File"+(count > 1 ? "(s)": "")+" Successfully Uploaded.");
        
    });
    
    myForm.attachEvent("onUploadFail", function(realName) {
        
        var upld = document.getElementsByClassName("button_upload");
        for (var i = 0; i < upld.length; i++)
        {
            upld[i].style.display = "none";
        }
        
        if(displayMsg == false)
        {
            alert("File upload fail due to some problem.");
        }
    });
    
    myForm.attachEvent("onUploadFile", function (realName, serverName)
    {
      
    });
    
}

function validate_form()
{
    var name = document.studentForm.txtsname.value;
    var add = document.studentForm.txtsadd.value;
    var city = document.studentForm.txtscity.value;
    var email = document.studentForm.txtsemail.value;
    var gen = document.studentForm.radiogender.value;
    var dob = document.studentForm.dtdob.value;
    var degree = document.studentForm.dropdegree.value;
    var year = document.studentForm.dropyear.value;
    var hobby = document.studentForm.selhobby.value;
    
    var date = dob.substring(0,2);
    var month = dob.substring(3,5);
    var year1 = dob.substring(6,10);
    
    var myDate = new Date(year1, month - 1, date);
    var today = new Date();
    
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    
    if(date>31)
    {
        alert("ERROR : Please Select Valid Date");
        document.getElementById("dtdob").focus();
        return false;
    }
    if(month > 12)
    {
        alert("ERROR : Please Select Valid Month");
        document.getElementById("dtdate").focus();
        return false;
    }
    if (name === '')
    {
        alert("ERROR : Name Can't ba Blank");
        document.getElementById("txtsname").focus();
        return false;
    }
    if(!name.match(/^[a-zA-Z ]+$/))
    {
        alert("ERROR : Only ALphabets are Allowed");
        document.getElementById("txtsname").focus();
        return false;
    }
   
//    if (photo !== '')
//    {
//        var checkimg = photo.toLowerCase();
//        if (!checkimg.match(/(\.jpg|\.png|\.JPG|\.PNG|\.jpeg|\.JPEG)$/))
//        {
//            alert("Error: Please enter  Image  File Extensions .jpg,.png,.jpeg");
//            document.getElementById("txtsphoto").focus();
//            return false;
//        }
//    }
    
    if(add === '')
    {
        alert("ERROR : Address Can't be Blank");
        document.getElementById("txtsadd").focus();
        return false;
    }
    if(!add.match(/[a-zA-Z][a-zA-Z0-9\s\/\-]/))
    {
        alert("ERROR : Only Alphabets and Numbers are Allowed");
        document.getElementById("txtsadd").focus();
        return false;
    }
    if(!city.match(/^[a-zA-Z]+$/))
    {
        alert("ERROR : Only Alphabets are Allowed");
        document.getElementById("txtscity").focus();
        return false;
    }
    if(city === '')
    {
        alert("ERROR : City Can'l be Blank");
        document.getElementById("txtscity").focus();
        return false;
    }
    if(gen === '')
    {
        alert("ERROR : Please Select Gender")
        document.getElementById("radiogender").focus();
        return false;
    }
    
    if(email === '')
    {
        alert("ERROR : Email can't be Blank")
        document.getElementById("txtsemail").focus();
        return false;
    }
    if(!filter.test(email))
    {
        alert("ERROR : Please Enter Valid Email");
        document.getElementById("txtsemail").focus();
        return false;
    }
    
    if(myDate > today)
    {
        alert("ERROR : Entered Date is Greater then Today's Date");
        document.getElementById("dtdate").focus();
        return false;
    }
    if(degree === '' || degree === '-1')
    {
        alert("ERROR : Please Select Degree");
        document.getElementById("dropdegree").focus();
        return false;
    }
    if(year === '' || year === '-1')
    {
        alert("ERROR : Please Select Year");
        document.getElementById("dropyear").focus();
        return false;
    }
    if(hobby === '')
    {
        alert("ERROR : Please Select Atleast one Hobby");
        document.getElementById("selhobby").focus();
        return false; 
    }
    return true;
}

function DhtmlshowReport(rptfor)
{
    document.getElementById('basicReportDiv').style.display= "";
    showDetailGridReports(rptfor);   
    reArrangeColumns();
}


function reArrangeColumns()
{
    var col = document.getElementById("col_cmb1");
    var col2 = document.getElementById("col_cmb2");
    
    if(col2 != null && col2.length > 0)
    {
        var val="";
        for( var i =0; i< col.length; i++)
        {
            val = col[i].value;
            mygrid.setColumnHidden(parseInt(val), true);
        }
    }
}

var mygrid;

function showDetailGridReports(rptfor)
{
    
    var param = getFormData(document.studentForm);
    mygrid = new dhtmlXGridObject('gridbox');
    
    mygrid.setImagesPath(getFinLibPath() + "dhtmlxSuite/dhtmlxGrid/codebase/imgs/");
    mygrid.setHeader("<b>Sr.No</b>,<b>Enrollment No</b>,<b>Photo</b>,<b>Name</b>,<b>Address</b>,<b>City</b>,<b>Email</b>,<b>Date of Birth</b>,<b>Gender</b>,<b>Degree</b>,<b>Year/Sem</b>,<b>Hobby</b>,<b>EDIT</b>,<b>DELETE</b>");
    
    mygrid.setInitWidths("50,50,150,100,150,90,150,80,80,80,80,200,80,80");
    mygrid.setColAlign("center,left,center,left,center,center,center,center,center,center,center,center,center,center");
    
    mygrid.setColSorting("int,int,na,str,str,str,str,na,na,na,na,na,na,na");
    mygrid.setColTypes("ro,ro,ro,ro,ro,ro,ro,ro,ro,ro,ro,ro,ed,ed");
    mygrid.enableAutoWidth(true);
    mygrid.enableAutoHeight(true);
    mygrid.enableMultiline(true);
    mygrid.setDateFormat("%D-%m-%y");
    mygrid.attachHeader(",#numeric_filter,,#select_filter,,#select_filter,,,,#select_filter,#select_filter,#select_filter,,");
    mygrid.enableDragAndDrop(false);
    mygrid.enableColumnMove(true);
    mygrid.enableMultiselect(true);
    mygrid.enableColSpan(true);
    mygrid.setSkin("dhx_web");
    document.getElementById("pagingArea").innerHTML = "";
    document.getElementById("recinfoArea").innerHTML = "";
    mygrid.enablePaging(true, 10, 10, "pagingArea", true, "recinfoArea");
    mygrid.setPagingWTMode(true, true, true, [10, 20, 50]);
    mygrid.setPagingSkin("toolbar", "dhx_web");
    mygrid.init();
    
    
    
    if(rptfor == "edit")
    {
        mygrid.setColumnHidden(13, true);
        mygrid.load('student.fin?cmdAction=getfillGridReoprts&' + param, hideLoadingImg(), "json");
    }
    
    if(rptfor == "delete")
    {
        mygrid.setColumnHidden(12, true);
        mygrid.load('student.fin?cmdAction=getfillGridReoprts&' + param, hideLoadingImg(), "json");
    }
    
    if(rptfor == "cols")
    {
        mygrid.setColumnHidden(12, true);
        mygrid.setColumnHidden(13, true);
        
        mygrid.load('student.fin?cmdAction=getfillGridReoprts&' + param, hideLoadingImg(), "json");
        
    }
    
    if(rptfor == "view")
    {
        mygrid.setColumnHidden(12, true);
        mygrid.setColumnHidden(13, true);
        
        if(document.getElementById("rdoOnScreen").checked)
        {
            showLoadingImg();
            mygrid.load('student.fin?cmdAction=getfillGridReoprts&' + param, hideLoadingImg(), "json");
            //displayReportMenu('report_export_out');
        }
        else if(document.getElementById("srXlsRadio").checked)
        {
            generateSerEXCEL(param);
        }
        
    } 
}

function generateSerEXCEL()
{
    document.getElementById("studentForm").action = "student.fin?cmdAction=GenerateServerExcelSheet";
    document.getElementById("studentForm").target = "_blank";
    document.getElementById("studentForm").submit();
    
    displayReportMenu('report_filter_out');
    
    if (!document.getElementById("rdoOnScreen").checked)
    {
        hideDiv("basicReportDiv");
    }
}

function showLoadingImg()
{
    document.getElementById("loadingImageID").style.display = "";
}

function ShowReport()
{
    if(validateRptName())
    {
        document.getElementById("btnApply").type = "submit";
        document.studentForm.action = 'student.fin?cmdAction=getRptExportFile';
        document.getElementById("studentForm").target = "_blank";
        document.studentForm.submit();
        document.getElementById("reportName").focus();
        hide_menu('show_hide', 'load', 'nav_show', 'nav_hide');
    }
}

function validateRptName()
{
    if (document.getElementById("reportName").value == "")
    {
        alert("Please Enter Report Name");
        document.getElementById("reportName").focus();
        return false;
    }
    return true;
}


//function generateEXCEL()
//{
//    var param = getFormData(document.studentForm);
//    mygrid.toExcel('student.fin?cmdAction=generateExcel&reportName= ' + document.getElementById("reportName").value,'gray');
//    displayReportMenu('report_export_out');
//    
//}
//
//function generatePDF()
//{
//    var param = getFormData(document.studentForm);
//    mygrid.toPDF('student.fin?cmdAction=generatePDF&reportName= ' + document.getElementById("reportName").value,'gray');
//    displayReportMenu('report_export_out');
//    
//}

function hideLoadingImg()
{
    document.getElementById("loadingImageID").style.display = "none";
}

function DeleteLoader()
{
    document.getElementById("basicReportDiv").style.display = "none";
    var param = getFormData(document.studentForm);
    getSynchronousData('student.fin?cmdAction=DeleteLoader', param, 'load');
    
    document.getElementById("txtsdelete").focus();
    if(document.getElementById("load").style.display === "none")
    {
        hide_menu('show_hide','load','nav_show','nav_hide');
    }
}

function ViewLoader()
{
    document.getElementById("basicReportDiv").style.display = "none";
    var param = getFormData(document.studentForm);
    getSynchronousData('student.fin?cmdAction=ViewLoader', param, 'load');
    document.getElementById("txtsview").focus();
    if(document.getElementById("load").style.display === "none")
    {
        hide_menu('show_hide','load','nav_show','nav_hide')
    }   
}


function FileLoader()
{
    document.getElementById("basicReportDiv").style.display = "none";
    var param = getFormData(document.studentForm);
    getSynchronousData('student.fin?cmdAction=fileLoader', param, 'load');
    doOnLoadFile();
    if(document.getElementById("load").style.display === "none")
    {
        hide_menu('show_hide','load','nav_show','nav_hide')
    }
}


var myUpload;
function doOnLoadFile()
{
 
    var formData;
    var param = getFormData(document.studentForm);
    var swfPathStr="http://dev.njindiaonline.com/finlibrary/dhtmlxSuite/dhtmlxForm/codebase/ext/uploader.swf";
    //dhtmlx.skin = "dhx_web";
    
    formData = [{
        type: "fieldset",
        label: "Upload File",
        list:[{
            type: "upload",
            name: "myFiles",
            inputWidth: 200,
            
            url: "student.fin?cmdAction=fileUpload",
            autoStart: true,
            swfPath: swfPathStr,
//            swfUrl: "student.fin?cmdAction=fileUpload"
        }]
    }];
    
    
    myForm = new dhtmlXForm("dthmlxExcel", formData);
    
    
    var count = 0;
   
   var upld = document.getElementsByClassName("button_upload");
    for (var i = 0; i < upld.length; i++)
    {
        upld[i].style.display = "none";
    }
    var browse = document.getElementsByClassName("button_browse");
    for (var i = 0; i < browse.length; i++)
    {
        browse[i].style.right = "25px";
    }
    
    myForm.attachEvent("onClear", function () {
        
        var upld = document.getElementsByClassName("button_upload");
        for (var i = 0; i < upld.length; i++)
        {
            upld[i].style.display = "none";
        }
    });
    
    myForm.attachEvent("onBeforeFileAdd",function(realName, size){
        
        count++;
        displayMsg = true;
        
        var upld = document.getElementsByClassName("button_upload");
        for (var i = 0; i < upld.length; i++)
        {
            upld[i].style.display = "none";
        }
        
        if (count > 1)
        {
            alert("You can enter only 1 file");
            if (count !== 0)
            {
                count = count - 1;
            }
            return false;
        }
        
        if (size > 1048576)
        {
            if (count !== 0)
            {
                count = count - 1;
            }
            alert("File size should not be greater then 1 MB");
            return false;
        }
        
        var reExp=/(.xls)$/i;
        if(!reExp.test(realName))
        {
            alert("Please upload valid file '"+realName+"'. The file must be with .xls extensions.");
            count = count - 1;
            return false;
        }
        else
        {
            return true;
        }
        
    });
    
    myForm.attachEvent("onFileRemove", function (realName, serverName) {
        
        var upld = document.getElementsByClassName("button_upload");
        for (var i = 0; i < upld.length; i++)
        {
            upld[i].style.display = "none";
        }
        if (count !== 0)
        {
            count = count - 1;
        }
       
        displayMsg = false;
    });
    
    myForm.attachEvent("onUploadComplete", function(count) {
        
        var upld = document.getElementsByClassName("button_upload");
        for (var i = 0; i < upld.length; i++)
        {
            upld[i].style.display = "none";
        }
        
        alert("On Up Comp == "+count);
        alert("File"+(count > 1 ? "(s)": "")+" Successfully Uploaded.");
        
    });
    
    myForm.attachEvent("onUploadFail", function(realName) {
        
        var upld = document.getElementsByClassName("button_upload");
        for (var i = 0; i < upld.length; i++)
        {
            upld[i].style.display = "none";
        }
        if(displayMsg == false)
        {
            alert("File upload fail due to some problem.");
        }
    });
    
}

function ReportLoader()
{
    document.getElementById("basicReportDiv").style.display = "none";
    var param = getFormData(document.studentForm);
    getSynchronousData('student.fin?cmdAction=ReportLoader', param, 'load');
    
    document.getElementById("reportName").focus();
    if(document.getElementById("load").style.display === "none")
    {
        hide_menu('show_hide','load','nav_show','nav_hide')
    }
}

function DeleteData(val)
{
    var param = getFormData(document.studentForm);
    param += "&primekey=" + val;
    getSynchronousData('student.fin?cmdAction=DeleteLoaderMain', param, 'load');
   
    document.getElementById("basicReportDiv").style.display = "none";
    if(document.getElementById("load").style.display === "none")
    {
        hide_menu('show_hide','load','nav_show','nav_hide');
    }
}

function EditData(val)
{
    var param = getFormData(document.studentForm);
    param += "&primekey=" + val;
    getSynchronousData('student.fin?cmdAction=EditLoaderMain', param, 'load');
    onLoadBody();
    //getDegree();
    
    //document.getElementById("txtsedit").focus();
    loadDatePicker("dtdob");
    doOnLoadEdit();
    document.getElementById("txtsname").focus();
    //document.getElementById("basicReportDiv").innerHTML="";
    document.getElementById("basicReportDiv").style.display = "none";
    if(document.getElementById("load").style.display === "none")
    {
        hide_menu('show_hide','load','nav_show','nav_hide')
    }
}

function onLoadBody()
{
    loadComboNew("dropdegree", "", "", "studentForm");
    loadComboNew("dropyear", "", "", "studentForm");
}